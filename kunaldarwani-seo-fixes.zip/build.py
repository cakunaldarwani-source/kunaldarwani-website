#!/usr/bin/env python3
"""Static site builder for Kunal Darwani & Company, Chartered Accountants.

Usage:  python build.py            -> builds into ./dist
        python build.py --drafts   -> also renders posts marked `draft: true`

Content lives in:
  data/site.json          firm details and partners
  data/categories.json    service categories (display order)
  data/compliance.json    compliance calendar
  content/services/*.md   one file per service (front matter + body)
  content/blog/*.md       blog posts (front matter + body). `service:` links a post to a service page.
  content/pages/*.md      static pages (disclaimer, privacy, about)
"""
import json, re, shutil, sys, datetime as dt
from pathlib import Path
from xml.sax.saxutils import escape

import markdown
import yaml
from jinja2 import Environment, FileSystemLoader, select_autoescape

ROOT = Path(__file__).parent
DIST = ROOT / "dist"
SHOW_DRAFTS = "--drafts" in sys.argv

MD = markdown.Markdown(extensions=["extra", "sane_lists", "toc"])


def parse_md(path: Path):
    text = path.read_text(encoding="utf-8")
    meta, body = {}, text
    if text.startswith("---"):
        _, fm, body = text.split("---", 2)
        meta = yaml.safe_load(fm) or {}
    MD.reset()
    html = MD.convert(body.strip())
    words = len(re.findall(r"\w+", body))
    meta.setdefault("slug", path.stem)
    meta["html"] = html
    meta["reading_minutes"] = max(1, round(words / 200))
    return meta


def load_json(name):
    return json.loads((ROOT / "data" / name).read_text(encoding="utf-8"))


def fmt_date(d):
    if isinstance(d, str):
        d = dt.date.fromisoformat(d)
    return d.strftime("%-d %B %Y")


def main():
    site = load_json("site.json")
    categories = load_json("categories.json")
    compliance = load_json("compliance.json")
    upd_path = ROOT / "data" / "updates.json"
    updates = json.loads(upd_path.read_text(encoding="utf-8")) if upd_path.exists() else {"items": []}
    sum_path = ROOT / "data" / "summaries.json"
    summaries = json.loads(sum_path.read_text(encoding="utf-8")) if sum_path.exists() else {}
    for u in updates["items"]:
        u["date_human"] = fmt_date(u["date"])
        u["summary"] = summaries.get(u["link"], {}).get("summary", "")
    upd_news = [u for u in updates["items"] if u["kind"] == "news"]
    upd_circ = [u for u in updates["items"] if u["kind"] == "circular"]

    services = [parse_md(p) for p in sorted((ROOT / "content/services").glob("*.md"))]
    services.sort(key=lambda s: (s.get("order", 999), s["title"]))
    svc_by_slug = {s["slug"]: s for s in services}

    posts = []
    for p in (ROOT / "content/blog").glob("*.md"):
        post = parse_md(p)
        if post.get("draft") and not SHOW_DRAFTS:
            continue
        d = post.get("date")
        post["date"] = d if isinstance(d, dt.date) else dt.date.fromisoformat(str(d))
        post["date_human"] = fmt_date(post["date"])
        posts.append(post)
    posts.sort(key=lambda p: (p["date"], p["slug"]), reverse=True)

    for s in services:
        s["posts"] = [p for p in posts if p.get("service") == s["slug"]]
    for p in posts:
        p["service_obj"] = svc_by_slug.get(p.get("service"))

    cats = []
    for c in categories:
        c = dict(c)
        c["services"] = [s for s in services if s.get("category") == c["slug"]]
        cats.append(c)

    pages = {p.stem: parse_md(p) for p in (ROOT / "content/pages").glob("*.md")}

    env = Environment(loader=FileSystemLoader(ROOT / "templates"), autoescape=select_autoescape(["html"]))
    env.globals.update(site=site, categories=cats, year=dt.date.today().year,
                       build_date=dt.date.today().isoformat())

    if DIST.exists():
        shutil.rmtree(DIST)
    DIST.mkdir()
    shutil.copytree(ROOT / "static", DIST / "static")

    urls = []
    base = site["base_url"].rstrip("/")
    org = {
        "@type": "AccountingService", "@id": base + "/#firm",
        "name": f"{site['firm_name']}, {site['firm_type']}", "url": base + "/",
        "telephone": site["phones"][0], "email": site["email"],
        "address": {"@type": "PostalAddress", "streetAddress": ", ".join(site["address_lines"][:2]),
                    "addressLocality": "Agra", "postalCode": "282001", "addressRegion": "Uttar Pradesh",
                    "addressCountry": "IN"},
        "areaServed": "IN",
    }

    def page_url(out):
        return f"{base}/{out}".replace("/index.html", "/")

    def render(tpl, out, depth=0, schema=None, lastmod=None, og_type="website", **ctx):
        rel = "../" * depth
        url = page_url(out)
        graph = [org] + ([schema] if schema else []) + list(ctx.pop("extra_schema", None) or [])
        ld = json.dumps({"@context": "https://schema.org", "@graph": graph}, ensure_ascii=False).replace("</", "<\\/")
        html = env.get_template(tpl).render(rel=rel, canonical=url, og_type=og_type, jsonld=ld, **ctx)
        target = DIST / out
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(html, encoding="utf-8")
        # Only real content dates go in the sitemap: stamping every page with the build date on
        # each daily build teaches Google to ignore <lastmod> for the whole site.
        urls.append((out, lastmod))

    render("updates.html", "updates.html", updates=updates, upd_news=upd_news, upd_circ=upd_circ,
           page_title="Latest News & Notifications", nav="updates")
    render("home.html", "index.html", services=services, posts=posts[:3],
           upd_news=upd_news[:6], upd_circ=upd_circ[:6], updates=updates,
           compliance=compliance, page_title=None, nav="home")
    render("services.html", "services/index.html", 1, page_title="Services", nav="services")
    for s in services:
        # Title tag carries the city for local search ("GST Registration in Agra");
        # the on-page H1 stays as the plain service name. A service can override with seo_title.
        render("service.html", f"services/{s['slug']}.html", 1, s=s,
               page_title=s.get("seo_title") or f"{s['title']} in Agra", description=s.get("summary"), nav="services")
    render("blog.html", "blog/index.html", 1, posts=posts, page_title="Knowledge Centre", nav="blog")
    partners_by_name = {x["name"]: x for x in site.get("partners", [])}

    def author_schema(name):
        """Person schema linked to the partner's profile, so Google can tie the article to a real, qualified author."""
        a = {"@type": "Person", "name": name}
        partner = partners_by_name.get(name)
        if partner:
            a["url"] = f"{base}/partners.html#{partner['slug']}"
            a["jobTitle"] = "Chartered Accountant"
            if partner.get("qualifications"):
                a["honorificSuffix"] = partner["qualifications"]
            a["worksFor"] = {"@id": base + "/#firm"}
        return a

    for p in posts:
        p["author_slug"] = (partners_by_name.get(p.get("author")) or {}).get("slug")
        same = [q for q in posts if q is not p and q.get("service") == p.get("service")]
        others = [q for q in posts if q is not p and q not in same]
        p["related"] = (same + others)[:3]
        desc = p.get("meta_description") or p.get("summary")
        url = page_url(f"blog/{p['slug']}.html")
        article = {"@type": "Article", "headline": p["title"][:110], "description": desc,
                   "datePublished": p["date"].isoformat(),
                   "dateModified": str(p.get("updated") or p["date"]),
                   "author": author_schema(p.get("author", "CA. Kunal Darwani")),
                   "publisher": {"@id": base + "/#firm"}, "mainEntityOfPage": url,
                   "inLanguage": "en-IN"}
        if p.get("keywords"):
            article["keywords"] = ", ".join(p["keywords"]) if isinstance(p["keywords"], list) else p["keywords"]
        faq = p.get("faq") or []
        faq_schema = {"@type": "FAQPage", "mainEntity": [
            {"@type": "Question", "name": f["q"], "acceptedAnswer": {"@type": "Answer", "text": f["a"]}}
            for f in faq]} if faq else None
        og_image = None
        try:  # branded social cards: Instagram (portrait) + Google / link preview (wide)
            from scripts.make_social_image import card, card_wide
            (DIST / "social").mkdir(exist_ok=True)
            card(p, p["slug"], DIST / "social" / f"{p['slug']}.png")
            card_wide(p, p["slug"], DIST / "social" / f"{p['slug']}-wide.png")
            og_image = f"{base}/social/{p['slug']}-wide.png"
            article["image"] = og_image
        except Exception as e:  # never break the site build over an image
            print(f"  social image skipped for {p['slug']}: {e}")
        render("post.html", f"blog/{p['slug']}.html", 1, p=p, page_title=p.get("seo_title") or p["title"],
               description=desc, nav="blog", og_type="article", schema=article, og_image=og_image,
               extra_schema=[faq_schema] if faq_schema else None,
               lastmod=str(p.get("updated") or p["date"]))
    render("partners.html", "partners.html", page_title="Partners", nav="partners")
    render("calendar.html", "compliance-calendar.html", compliance=compliance,
           page_title="Compliance Calendar", nav="calendar")
    render("contact.html", "contact.html", page_title="Contact", nav="contact")
    render("careers.html", "careers.html", page_title="Careers",
           description="Careers at Kunal Darwani & Company, Chartered Accountants, Agra. Apply for articleship, CA, accounts and tax roles.", nav="careers")
    art = load_json("articleship.json")
    art_url = page_url("articleship-in-agra.html")
    art_faq = {"@type": "FAQPage", "mainEntity": [
        {"@type": "Question", "name": f["q"], "acceptedAnswer": {"@type": "Answer", "text": f["a"]}}
        for f in art["faq"]]}
    job = None
    if art.get("open"):
        st = art["stipend"]
        job = {"@type": "JobPosting", "title": "Articled Assistant (CA Articleship)",
               "description": ("<p>Two-year CA articleship (ICAI New Scheme) with Kunal Darwani &amp; Company, "
                               "Chartered Accountants, Agra. Training focuses on statutory audits, bank audits and income tax / GST litigation, "
                               "along with tax, GST, ROC and accounting work, handled end to end with AI tools under the partners' supervision.</p>"
                               "<p>Eligibility: passed both groups of CA Intermediate and completed ICITSS.</p>"
                               f"<p>Stipend: Rs. {st['year1']:,} a month in the first year and Rs. {st['year2']:,} in the second year, "
                               f"plus Rs. {st['single_attempt_bonus']:,} a month for students who cleared both Intermediate groups in a single attempt.</p>"),
               "datePosted": art["date_posted"], "validThrough": art["valid_through"] + "T23:59:59+05:30",
               "employmentType": "INTERN", "industry": "Accounting",
               "hiringOrganization": {"@type": "Organization", "name": f"{site['firm_name']}, {site['firm_type']}",
                                      "sameAs": base + "/"},
               "jobLocation": {"@type": "Place", "address": org["address"]},
               "baseSalary": {"@type": "MonetaryAmount", "currency": "INR",
                              "value": {"@type": "QuantitativeValue", "minValue": st["year1"],
                                        "maxValue": st["year2"] + st["single_attempt_bonus"], "unitText": "MONTH"}},
               "educationRequirements": "CA Intermediate (both groups) and ICITSS", "url": art_url}
    render("articleship.html", "articleship-in-agra.html", a=art, schema=job, extra_schema=[art_faq],
           page_title="CA Articleship in Agra – Stipend & How to Apply",
           description=(f"CA articleship in Agra with Kunal Darwani & Company, Chartered Accountants: 2-year ICAI New Scheme "
                        f"training in statutory audit, bank audit and litigation, stipend Rs. {art['stipend']['year1']:,}–{art['stipend']['year2']:,} a month, and how to apply."),
           nav="careers")
    for slug, pg in pages.items():
        render("page.html", f"{slug}.html", pg=pg, page_title=pg["title"], description=pg.get("meta_description"), nav=slug)

    # sitemap + RSS
    sm = ['<?xml version="1.0" encoding="UTF-8"?>',
          '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    sm += [f"  <url><loc>{page_url(u)}</loc>" + (f"<lastmod>{lm}</lastmod>" if lm else "") + "</url>" for u, lm in urls]
    sm.append("</urlset>")
    (DIST / "sitemap.xml").write_text("\n".join(sm), encoding="utf-8")
    (DIST / "robots.txt").write_text(f"User-agent: *\nAllow: /\nSitemap: {base}/sitemap.xml\n")

    items = "".join(
        f"<item><title>{escape(p['title'])}</title><link>{base}/blog/{p['slug']}.html</link>"
        f"<guid>{base}/blog/{p['slug']}.html</guid>"
        f"<pubDate>{p['date'].strftime('%a, %d %b %Y 00:00:00 +0530')}</pubDate>"
        f"<description>{escape(p.get('summary', ''))}</description></item>"
        for p in posts[:30])
    rss = (f'<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel>'
           f"<title>{escape(site['firm_name'])} – Knowledge Centre</title><link>{base}/blog/</link>"
           f"<description>Tax, GST, company law and accounting updates</description>{items}</channel></rss>")
    (DIST / "blog" / "feed.xml").write_text(rss, encoding="utf-8")
    (DIST / "CNAME").write_text(site["domain"] + "\n")

    print(f"Built {len(urls)} pages: {len(services)} services, {len(posts)} posts -> {DIST}")


if __name__ == "__main__":
    main()
